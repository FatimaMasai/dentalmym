<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- Meta -->
  <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
  <meta name="author" content="ThemePixels"> 
  <title>Consultorio Dental M&M</title>  
  <!-- vendor css -->
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/jquery-switchbutton/jquery.switchButton.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/rickshaw/rickshaw.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/chartist/chartist.css')); ?>" rel="stylesheet">

  <!-- Bracket CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/bracket.css')); ?>">
</head>

<body>
    <div id="app">
      <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
          <div class="container"> 
                  <!-- Right Side Of Navbar -->
                  <ul class="navbar-nav ml-auto">
                      <!-- Authentication Links -->
                      <?php if(auth()->guard()->guest()): ?>
                          <?php if(Route::has('login')): ?>
                              <!-- <li class="nav-item">
                                  <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                              </li>  -->
                          <?php endif; ?>
                          
                          <?php if(Route::has('register')): ?>
                              <!-- <li class="nav-item">
                                  <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                              </li> -->
                          <?php endif; ?>
                      <?php else: ?> 
                      <div class="br-logo"><a href=""><span>[</span> Dental M&M <span>]</span></a></div> 
                          <div class="br-header">
                              <div class="br-header-left">
                                  <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
                                  <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>
                                  <div class="input-group hidden-xs-down wd-170 transition">
                                      <input id="searchbox" type="text" class="form-control" placeholder="Search">
                                      <span class="input-group-btn">
                                          <button class="btn btn-secondary" type="button"><i class="fa fa-search"></i></button>
                                      </span>
                                  </div> 
                              </div> 
                              <div class="br-header-right">
                                  <nav class="nav"> 
                                      <div class="dropdown">
                                          <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
                                          <span class="logged-name hidden-md-down"><?php echo e(Auth::user()->name); ?></span>
                                          <img src="<?php echo e(asset('img/logo-dental.png')); ?>" class="wd-32 rounded-circle" alt="">
                                          <span class="square-10 bg-success"></span>
                                          </a>
                                          <div class="dropdown-menu dropdown-menu-header wd-200">
                                              <ul class="list-unstyled user-profile-nav"> 
                                                  <li>
                                                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                      onclick="event.preventDefault();
                                                                      document.getElementById('logout-form').submit();">
                                                          <?php echo e(__('Salir')); ?>

                                                      </a>
                                                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                          <?php echo csrf_field(); ?>
                                                      </form>
                                                      </a>
                                                  </li>
                                              </ul>
                                          </div> 
                                      </div> 
                                  </nav> 
                              </div> 
                          </div> 
                      </div>
                          
                      <?php endif; ?>
                  </ul>
              </div>
          </div>
      </nav>
      <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('layouts.contenido', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
      <main class="py-4">
          <?php echo $__env->yieldContent('content'); ?> 
      </main>
      
    </div>

    <script src="<?php echo e(asset('lib/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/popper.js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/bootstrap/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery-ui/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery-switchbutton/jquery.switchButton.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/peity/jquery.peity.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/chartist/chartist.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery.sparkline.bower/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/d3/d3.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/rickshaw/rickshaw.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/bracket.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ResizeSensor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
    <script>
      $(function(){
        'use strict'

        // FOR DEMO ONLY
        // menu collapsed by default during first page load or refresh with screen
        // having a size between 992px and 1299px. This is intended on this page only
        // for better viewing of widgets demo.
        $(window).resize(function(){
          minimizeMenu();
        });

        minimizeMenu();

        function minimizeMenu() {
          if(window.matchMedia('(min-width: 992px)').matches && window.matchMedia('(max-width: 1299px)').matches) {
            // show only the icons and hide left menu label by default
            $('.menu-item-label,.menu-item-arrow').addClass('op-lg-0-force d-lg-none');
            $('body').addClass('collapsed-menu');
            $('.show-sub + .br-menu-sub').slideUp();
          } else if(window.matchMedia('(min-width: 1300px)').matches && !$('body').hasClass('collapsed-menu')) {
            $('.menu-item-label,.menu-item-arrow').removeClass('op-lg-0-force d-lg-none');
            $('body').removeClass('collapsed-menu');
            $('.show-sub + .br-menu-sub').slideDown();
          }
        }
      });
    </script>
    <script src = "https://code.iconify.design/1/1.0.7/iconify.min.js"> </script>
  </body>
</html>

<?php /**PATH C:\xampp\htdocs\sistema-v\resources\views/layouts/app.blade.php ENDPATH**/ ?>